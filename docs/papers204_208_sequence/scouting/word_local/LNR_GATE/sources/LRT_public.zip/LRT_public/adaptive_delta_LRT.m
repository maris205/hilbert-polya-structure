 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Y=adaptive_delta_LRT(X,scale)
% Computes adaptive delta local rank transform of an gray scale image X
% delta= scale* avg_neighboring_value

[height width depth]=size(X);

Y=zeros(height,width);
Avg=zeros(height,width);


%computes average values
for i=1:height
    for j=1:width
         count=0;
         sum=0;
          for k=-1:1
            for l=-1:1
                if(((i+k)>0) && ((i+k)<=height))
                    if(((j+l)>0) && ((j+l)<=width))
                        if((l~=0) && (k~=0))
                            count=count+1;
                            sum=sum+X(i,j);
                        end
                    end
                end
            end
        end
         Avg(i,j)=sum/count;
    end
end



for i=1:height
    for j=1:width
        delta=scale*Avg(i,j);
        rank_count=0;
        for k=-1:1
            for l=-1:1
                if(((i+k)>0) && ((i+k)<=height))
                    if(((j+l)>0) && ((j+l)<=width))
                        if(X(i+k,j+l)+delta <X(i,j))
                            rank_count=rank_count+1;
                        end
                    end
                end
            end
        end
         Y(i,j)=rank_count;
    end
end
return