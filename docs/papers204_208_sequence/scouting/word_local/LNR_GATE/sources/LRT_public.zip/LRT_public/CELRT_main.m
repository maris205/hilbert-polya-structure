%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementation of CELRT algorithm  as discussed in the following paper:
% "Jayanta Mukherjee, Local rank transform: properties and applications, Pattern Recognition Letters, 32, 1001-1008, 2011."
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sprintf('Color image enhancement using CELRT:');
 clear
 tic
 
 outputdir='results/CELRT_output/';
 imagedir='./';
 
 imagefile='image22';

 
 image=[sprintf(imagedir) sprintf(imagefile)];
 deltaP=10;
 deltaN=-10;
 sthresh=10;
 lamdaP=0.5; % Sharpening factor
 lamdaN=0.5; % Background illumination factor
 lamda_attrP=0.5;
 lamda_attrN=0.5;
 niter=3;
 FSAVE=1; % File Saving
 nx=3;
 ny=3; % (2nx+1).(2ny+1) neighborhood size
 comp_thresh=10; %compensation threshold to avoid division by small numbers
 
 %CI 		= imread( [sprintf(image) '.bmp'],'bmp');
 CI 		= imread( [sprintf(image) '.jpg'],'jpg');

% CI 		= imread( [sprintf(image) '.JPG'],'jpg');

 [height width depth]=size(CI); 
 
 figure(1); imshow(uint8(CI)); title('Original Image');
 
 
 if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile)];
 %   saving original image
     imwrite(uint8(CI),[ofname,'.BMP'],'BMP');
     sprintf('Original Image saved in %s ', ofname)
 end
 
 cm_orig=colourfulness_metric(CI);
 
 CI_ycbcr=double(RGB_YCbCr(CI));
 
 Y=CI_ycbcr(:,:,1);
 Cb=CI_ycbcr(:,:,2);
 Cr=CI_ycbcr(:,:,3);
 
 
 outP=delta_LRT_extended_neighborhood(Y,deltaP,nx,ny);
 outN=delta_LRT_extended_neighborhood(Y,deltaN,nx,ny);
 outP_interval=double(LTR_component(outP,1,100));
 outN_interval=double(LTR_component(outN,1,100));
figure(2); imshow(uint8(imadjust(uint8(outP_interval)))); title('Adjusted rank image');
 
 sharp_out= Y+ lamdaP * outP_interval+ lamdaN * outN_interval;
 
 sprintf('EMEE Original Y: %f',EMEE(Y,4,1.0))
 sprintf('EMEE Enhanced Y: %f',EMEE(sharp_out,4,1.0))
 
  
  sharp_CI_ycbcr(:,:,1)=sharp_out;
  sharp_CI_ycbcr(:,:,2)=Cb;
  sharp_CI_ycbcr(:,:,3)=Cr;
  sharp_CI=YCbCr_RGB(sharp_CI_ycbcr);
  
  figure(3); imshow(uint8(uint8(sharp_CI))); title('Sharpened Image');
  
   if(FSAVE>0)
      ofname=[sprintf(outputdir)  sprintf(imagefile) '_enh_ltr'];
 %   saving attractor image
     imwrite(uint8(sharp_CI),[ofname,'.BMP'],'BMP');
     sprintf('Enhanced Image saved in %s ', ofname)
   end
   
  sharp_CI_ycbcr=CI_ycbcr;
  sharp_CI_ycbcr(:,:,1)=sharp_out;
  for i=1:height
      for j=1:width
          if(Y(i,j)>comp_thresh)
            sharp_CI_ycbcr(i,j,2)=(sharp_out(i,j)/Y(i,j))*(Cb(i,j)-128)+128;
            sharp_CI_ycbcr(i,j,3)=(sharp_out(i,j)/Y(i,j))*(Cr(i,j)-128)+128;
          end
      end
  end
  sharp_CI=YCbCr_RGB(sharp_CI_ycbcr);
  
  figure(4); imshow(uint8(sharp_CI)); title('Chroma Compensated Enhancement');
  
  cm_sharp=colourfulness_metric(sharp_CI);
  sprintf('CEF: Sharpened Image = %f',cm_sharp/cm_orig)
  
   if(FSAVE>0)
      ofname=[sprintf(outputdir)  sprintf(imagefile) '_enh_ltr_chr_comp'];
 %   saving attractor image
     imwrite(uint8(sharp_CI),[ofname,'.BMP'],'BMP');
     sprintf('Chroma Compensated Enhanced Image saved in %s ', ofname)
  end
  

 
 for i=1:niter
     outP=LRT(outP);
     outN=LRT(outN);
     
 end
sharp_out= sharp_out + lamda_attrP * outP + lamda_attrN * outN;
 
 figure(5); imshow(uint8(imadjust(uint8(outP)))); title('Adjusted Attractor  Image');

  
 figure(6); imshow(uint8(uint8(sharp_out))); title('Attractor Sharpened Image');
  sharp_CI_ycbcr=CI_ycbcr;
  sharp_CI_ycbcr(:,:,1)=sharp_out;
  
  for i=1:height
      for j=1:width
          if(Y(i,j)>comp_thresh)
            sharp_CI_ycbcr(i,j,2)=(sharp_out(i,j)/Y(i,j))*(Cb(i,j)-128)+128;
            sharp_CI_ycbcr(i,j,3)=(sharp_out(i,j)/Y(i,j))*(Cr(i,j)-128)+128;
          end
      end
  end
  
  sharp_CI=YCbCr_RGB(sharp_CI_ycbcr);
  
  figure(7); imshow(uint8(uint8(sharp_CI))); title('Chroma Compensated: Attractor Sharpened Color Image');
  sprintf('EMEE Attractor based Enhanced Y: %f',EMEE(sharp_out,4,1.0))
  
  cm_sharp=colourfulness_metric(sharp_CI);
  sprintf('CEF: Attractor based Sharpened Image = %f',cm_sharp/cm_orig)
 

 toc