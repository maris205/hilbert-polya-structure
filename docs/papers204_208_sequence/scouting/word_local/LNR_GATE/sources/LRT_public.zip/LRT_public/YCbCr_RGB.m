 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out=YCbCr_RGB(I)

% Apply median filtering to supress false colors

Tr1 = [0.5022    0.0975    0.2558; -0.2899    0.4375   -0.1476; -0.3664   -0.0711    0.4375];
Tr3 = inv(Tr1);
% Tr1 =       [ 0.299   0.587   0.114
%              -0.173  -0.339   0.511
%               0.511  -0.428  -0.083];
% Tr3 = inv(Tr1);

Y= double(I(:,:,1));
Cb = double(I(:,:,2));
Cr= double(I(:,:,3));

% Y 	= Tr1(1,1)*G +	Tr1(1,2)*B + Tr1(1,3)*R; 
% Cb	= Tr1(2,1)*G +	Tr1(2,2)*B + Tr1(2,3)*R + 128;
% Cr	= Tr1(3,1)*G +	Tr1(3,2)*B + Tr1(3,3)*R + 128;



G = Tr3(1,1)*Y + Tr3(1,2)*(Cb-128) + Tr3(1,3)*(Cr-128);
B = Tr3(2,1)*Y + Tr3(2,2)*(Cb-128) + Tr3(2,3)*(Cr-128);
R = Tr3(3,1)*Y + Tr3(3,2)*(Cb-128) + Tr3(3,3)*(Cr-128);  


 out(:,:,1) = R;
out(:,:,2) =  G;
out(:,:,3) =  B;

  out=uint8(out);
 
  return