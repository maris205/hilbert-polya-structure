 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementation of  LRT  as discussed in the following paper:
% "Jayanta Mukherjee, Local rank transform: properties and applications, Pattern Recognition Letters, 32, 1001-1008, 2011."
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 sprintf('Local Rank Transform: Experiments');
 clear
 tic
 
 outputdir='results/LRT_output/';
 imagedir='./';
 imagefile='window';
 FSAVE=1;
 
 image=[sprintf(imagedir) sprintf(imagefile)];
 
 CI 		= imread( [sprintf(image) '.bmp'],'bmp');
 [height width depth]=size(CI);
 
 figure(1); imshow(uint8(CI)); title('Original Image');
 
 
 
 
 CI_ycbcr=RGB_YCbCr(CI);
 
 Y=CI_ycbcr(:,:,1);
 Cb=CI_ycbcr(:,:,2);
 Cr=CI_ycbcr(:,:,3);
 
 figure(2); imshow(uint8(Y)); title('Intensity Image');
 
 out=LRT(Y);
 figure(3); imshow(uint8(imadjust(uint8(out)))); title('Rank Image');
 
  if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile) '_lrt'];
 %   saving LRT image
     imwrite((imadjust(out)),[ofname,'.BMP'],'BMP');
     sprintf('Adjusted Rank Image saved in %s ', ofname)
 end
 
 while(1)
     tmp=LRT(out);
     ndiff=check_difference(out,tmp);
     if(ndiff==0)
         break;
     end
     out=tmp;
 end
 
 adjust_out=imadjust(uint8(out));
 
  figure(4); imshow(uint8(adjust_out)); title('Converged Rank Image');
  
   if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile) '_attr'];
 %   saving LRT image
     imwrite(adjust_out,[ofname,'.BMP'],'BMP');
     sprintf('Adjusted Rank Image saved in %s ', ofname)
   end
 toc