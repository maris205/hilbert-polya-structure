 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ratio=compare_binary_images(X,Y)
% X and Y of same size with values 0 or 1
[height width depth]=size(X);


ncommon=0;
nsum=0;
% nX=sum(sum(X));
% nY=sum(sum(Y));
% nsum=nX+nY;
for i=1:height
    for j=1:width
        if((X(i,j)==1) || (Y(i,j)==1))
            nsum=nsum+1;
        end
    end
end
for i=1:height
    for j=1:width
        if((X(i,j)==1) && (Y(i,j)==1))
            ncommon=ncommon+1;
        end
    end
end
 ratio=double(ncommon)/double(nsum);
return