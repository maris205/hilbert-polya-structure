 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diff_no=check_difference(X,Y)
% Returns the number of pixels differed in X and Y assuming their sizes are
% same.

[hx wx]=size(X);
[hy wy]=size(Y);

 if((hx~=hy) && (hy~=wy))
     diff_no=-1;
     return
 end
 
 diff_no=0;
 for i=1:hx
     for j=1:wx
         if(X(i,j)~=Y(i,j))
             diff_no=diff_no+1;
         end
     end
 end
 return