 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function val=EMEE(I,blk_size,alpha)
% Measure of Enhancement by Entropy
[height width depth]=size(I);

sum=0;
count=0;
for l=0:height/blk_size-1
    for m=0:width/blk_size-1
           blk_val=measure_single_block(I(l*blk_size+1:l*blk_size+blk_size,m*blk_size+1:m*blk_size+blk_size,:),alpha);
           sum=sum+blk_val;
           count=count+1;
    end
end
val=sum/double(count);         
return