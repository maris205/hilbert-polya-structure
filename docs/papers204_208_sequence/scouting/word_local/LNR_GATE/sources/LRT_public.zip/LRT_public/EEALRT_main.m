%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implementation of EEALRT  algorithm as discussed in the following paper:
% "Jayanta Mukherjee, Local rank transform: properties and applications, Pattern Recognition Letters, 32, 1001-1008, 2011."
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sprintf('Edge Extraction using  Adaptive delta Rank Transform');
 clear
 tic
 
 outputdir='results/EEALRT_output/';
 imagedir='./';
 
 imagefile='window';
 
  
 image=[sprintf(imagedir) sprintf(imagefile)];
 scale=0.25;
 sthresh=0.05;
 FSAVE=1;
 
 CI 		= imread( [sprintf(image) '.bmp'],'bmp');
 [height width depth]=size(CI);
 
 figure(1); imshow(uint8(CI)); title('Original Image');
 

 CI_ycbcr=RGB_YCbCr(CI);
 
 Y=CI_ycbcr(:,:,1);
 Cb=CI_ycbcr(:,:,2);
 Cr=CI_ycbcr(:,:,3);
 
 figure(2); imshow(uint8(Y)); title('Intensity Image');
 
 if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile) '_int'];
 %   saving luminance image
     imwrite(uint8(Y),[ofname,'.BMP'],'BMP');
     sprintf('Luminance Image saved in %s ', ofname)
 end
  
 
 out=adaptive_delta_LRT(Y,scale);
  out_interval=LTR_component(out,1,9);

 
 out_binary=binary_thresholding(out,0);
 figure(3); imshow(out_binary); title('Edges from adaptive delta Rank Image');
 
 if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile) '_lrt_adapt_' sprintf('%d',10*scale)];
 %   saving LRT image
     imwrite((imadjust(out_interval)),[ofname,'.BMP'],'BMP');
     sprintf('Adjusted Rank Image saved in %s ', ofname)
 end
 
  
 while(1)
     tmp=LRT(out_interval);
     ndiff=check_difference(out,tmp);
     sprintf('ndiff= %d',ndiff)
     if(ndiff==0)
         break;
     end
     out=tmp;
 end
 
   adjust_out=imadjust(uint8(out));

  
  out_attractor_binary=binary_thresholding(out,0);
 
 figure(4); imshow(out_attractor_binary); title('Attractor binary image');
  
  if(FSAVE>0)
      ofname=[sprintf(outputdir)  sprintf(imagefile) '_attr_adapt_' sprintf('%d',10*scale)];
 %   saving attractor image
     imwrite(adjust_out,[ofname,'.BMP'],'BMP');
     sprintf('Adjusted Rank Image saved in %s ', ofname)
  end

  Y_canny= edge(Y,'canny');

figure(5); imshow(Y_canny); title('Canny Edge Operator');
Y_sobel= edge(Y,'sobel',sthresh);

figure(6); imshow(Y_sobel); title('Sobel Edge Operator');

[Y_log]= edge(Y,'log');

figure(7); imshow(Y_log); title('LoG Edge Operator');

if(FSAVE>0)
     ofname=[sprintf(outputdir)  sprintf(imagefile) '_sobel'];
 %   saving sobel image
     imwrite((Y_sobel),[ofname,'.BMP'],'BMP');
     sprintf('Adjusted Rank Image saved in %s ', ofname)
end


sprintf('Similarity (Sobel, Delta_rank)=%f',compare_binary_images(out_binary,Y_sobel))
sprintf('Similarity (Canny, Delta_rank)=%f',compare_binary_images(out_binary,Y_canny))
sprintf('Similarity (LoG, Delta_rank)=%f',compare_binary_images(out_binary,Y_log))

sprintf('Similarity (Sobel, Attractor_rank)=%f',compare_binary_images(out_attractor_binary,Y_sobel))
sprintf('Similarity (Canny, Attractor_rank)=%f',compare_binary_images(out_attractor_binary,Y_canny))
sprintf('Similarity (LoG, Attractor_rank)=%f',compare_binary_images(out_attractor_binary,Y_log))

 
 toc