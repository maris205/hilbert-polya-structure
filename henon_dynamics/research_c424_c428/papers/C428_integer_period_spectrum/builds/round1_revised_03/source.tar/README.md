# C428 manuscript: first-review revision handoff

**Status:** first actual nonauthor manuscript review addressed and
clean revised PDF frozen; awaiting the separate second manuscript
review. This is not final release,
external submission or an additional admitted contract.

Read [main.pdf](main.pdf), [SOURCE_AUDIT.md](SOURCE_AUDIT.md) and
[BUILD_LEDGER.md](BUILD_LEDGER.md), and
[PAPER_IMPROVEMENT_LOG.md](PAPER_IMPROVEMENT_LOG.md). The complete analytic proof, exact
certificate tables, realization witnesses and reconstruction
pseudocode are typeset in the manuscript; an external Markdown link
does not substitute for the proof.

## Complete editable source list

1. `main.tex` — anonymous 11pt article and deterministic PDF settings.
2. `references.bib` — three public primary sources and four actual
   unpublished internal records, with no invented human authors.
3. `sections/01_theorem_sources.tex` — exact family-union theorem,
   explicit source subtraction and proof organization.
4. `sections/02_secant.tex` — orbit normalization, integer secant
   remainder, magnitude bounds and value-difference divisibility.
5. `sections/03_large_reduction.tex` — exhaustive three-template
   reduction for every diameter at least ten and affine branch.
6. `sections/04_small_certificate.tex` — exact integral Newton
   interpolation, full-support graph proof and small certificate.
7. `sections/05_symbolic_certificate.tex` — affine edge identities,
   complete exceptional-root partition, author pruning, symbolic
   certificate and exclusion proof.
8. `sections/06_witnesses.tex` — all eleven exact realization witnesses
   and the negative eight-cycle's ordered-state check.
9. `sections/07_evidence_scope.tex` — exact historical execution
   record, SHA-256 identities, computational dependency and limits.
10. `sections/A_pseudocode.tex` — complete full-cycle extraction,
    small restriction enumeration, endpoint-template enumeration,
    unpruned symbolic graph partition and author pruning.
11. `sections/B_reconstruction.tex` — proof of equivalence for the
    alternative Lagrange interpolation and indegree-peeling checker;
    actual controls and interpretation of unpruned outputs.
12. `tables/small_diameter.tex` — all ten small-diameter count rows.
13. `tables/large_author.tex` — all six author symbolic-count rows.
14. `tables/large_independent.tex` — all six unpruned reconstruction
    rows, including every exceptional-root set.
15. `tables/witnesses.tex` — all eleven realization rows.

Every listed TeX file is included. Historical frozen proof/code/review
packages were read without modification, import or execution. The
initial build archives distinguish the actual first manuscript from
two small layout/command-typesetting corrections; neither is a
fabricated review revision.

The `paper-figure` workflow supplied the exact typeset tables, not
new visual or numerical evidence. `paper-compile` supplied real log,
font, text and complete-page checks. The batch plan overrides ML
venue quotas and external-model defaults. The actual first review is
preserved in `reviews/round1/REVIEW.md`; the exact three-file revision
diff is `reviews/round1/source_changes.diff`. The first-review revision
clarifies coordinate-keyed pseudocode maps, removes two duplicated
bibliography years and repairs one source-line-break hyphen space.
No theorem, table or mathematical execution changed. All 16 revised
pages were viewed and the complete extracted text read.

`main_round0_original.pdf` preserves the initial handoff. `main.pdf`
and `main_round1.pdf` are byte copies of
`builds/round1_revised_03/main.pdf`, SHA-256
`cf02bdd886584949847f2583904601bb2734010a5f9d9cafbcbe749ddb0553af`.
The second manuscript review, formal evaluation and final deterministic
build pair are still pending. The author stops writing at this handoff.
